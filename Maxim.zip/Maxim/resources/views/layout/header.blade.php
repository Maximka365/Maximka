<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>avtoriz</title>
    <link rel="stylesheet" href="css/style_login.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
@yield('content')
</body>
</html>
