@extends('layout.header')
@section('content')

<div class="main">
    <div class="logo">
        <a href="index.html"><img src="img/alpaka_logo.jpg" alt="" width="100"></a>
    </div>
    <div class="reg">
        <form action="/login" method="post" class="overbox">
            {{csrf_field()}}
            <h2>Ваш логин:</h2>
            <input TYPE="text"  name="name" size="30" placeholder="name" required>
            <br>
            <h2>Введите Ваш пароль:</h2>
            <input TYPE="password" name="password" size="30"  placeholder="password" required>
            <div class="button">
                <button type="submit">Войти</button>
                <button type="submit">Отмена</button>
            </div>
        </form>

    </div>
</div>
@endsection
