<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registration</title>
    <link rel="stylesheet" href="css/registration.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
<div class="main">
    <div class="logo">
        <a href="index.html"><img src="images/alpaka_logo.jpg" alt="" width="100"></a>
    </div>
    <div class="reg">
        <form action="/Registr" method="post">
            {{csrf_field()}}
            Ваш логин:<BR>
            <input TYPE="text" name="login" size="30">
            <br>
            E-mail:<BR>
            <input TYPE="text" name="email" size="30">
            <br>
            Введите Ваш пароль: <BR>
            <input TYPE="password" name="password" size="30">
            <br>
            Введите ваш пароль повторно: <br>
            <input TYPE="password" name="password" size="30">
            <br>
            <button type="submit">Зарегистрироваться</button>
            <a href="avtoriz.html"><button type="submit">Отмена</button></a>
        </form>

    </div>
</div>
</body>
</html>
