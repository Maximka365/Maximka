<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>alpakainflora</title>
    <link rel="stylesheet" href="css/style1.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
<div class="main">
    <header class="header">
        <a href="index.html"><img
                src="images/alpaka_logo.jpg" width="100"></a>
        <div class="search_box">
            <form>
                <input type="text" placeholder="Искать здесь...">
                <button type="submit"><img src="images/lupa.svg" alt=""></button>
            </form>
        </div>
        <div class="l_inform">
            <div class="l_inform_img">
                <img src="images/kolokol.png" width="40">
                <img src="images/messenge.png" width="40">
                <img src="images/avatarka.jpg" width="50">
            </div>
        </div>
    </header>
    <div class="content">
        <div class="content_left">
            <a href=""><img src="images/dobavleni_posta.png" width="50"></a>
            <a href=""><img src="images/grup.png" width="50"></a>
            <a href=""><img src="images/news.png" width="50"></a>
            <a href=""><img src="images/nastroiki.png" width="50"></a>
            <a href=""><img src="images/question.png" width="50"></a>
        </div>
        <div class="content_center">
            <div class="cc_top">
                <img src="images/alpaka_inf_1.jpg">
                <img id="aflora" src="images/ainflora/ainflora.png"
            </div>

        </div>
        <div class="cc_down">
            <h1>Альпака в мире природы</h1>
            <p>Легенда индейцев кечуа, потомков инков, гласит, что когда-то богиня Пачамама спустилась на Землю.
                Прародительницу всех людей сопровождала. Животное было избрано за необычность формы, незлобивость
                нрава и мягкость шерсти.
            </p>
            <p>
                Индейцы ценили животное, ниспосланное богами. Большинство жителей империи инков обходились одеждой
                из шерсти ламы. Только знать и духовенство могли пользоваться тканями, сделанными из шерсти альпака
            </p>
            <p>
                Европейцы часто не отличают альпака от ламы. Оба животных одомашнены. Могут давать общее потомство.
                Тем не менее они очень разные. Главное внешнее отличие: лама превосходит по весу и размерам альпака
                вдвое.
            </p>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Maxim\resources\views/alpakainflora.blade.php ENDPATH**/ ?>