<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>avtoriz</title>
    <link rel="stylesheet" href="css/avtoriz.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
<div class="main">
    <header class="header">
        <img src="images/alpaka_logo.jpg" width="100">
        <div class="search_box">
            <form>
                <input type="text" placeholder="Искать здесь...">
                <button type="submit"><img src="images/lupa.svg" alt=""></button>
            </form>
        </div>
        <div class="l_inform">
            <li><a href="/login">Войти</a></li>
            <li><a href="/Registr">Регистрация</a></li>
        </div>
    </header>
    <div class="filter">
        <nav class="four">
            <ul class="topmenu">
                <li><a href="#">Фильтры:</a></li>
                <li><a href="#">Новое</a></li>
                <li><a href="#">Страницы<i class="fa fa-angle-down"></i></a>
                    <ul class="submenu">
                        <li><a href="">Страница 1</a></li>
                        <li><a href="">Страница 2</a></li>
                    </ul>
                </li>
                <li><a href="#">Популярное</a></li>

            </ul>
        </nav>
    </div>
    <div class="content">
        <div class="content_left">
            <a href=""><img src="images/dobavleni_posta.png" width="50"></a>
            <a href=""><img src="images/grup.png" width="50"></a>
            <a href=""><img src="images/news.png" width="50"></a>
            <a href=""><img src="images/nastroiki.png" width="50"></a>
            <a href=""><img src="images/question.png" width="50"></a>
        </div>
        <div class="content_center">
            <div class="box">
                <img src="images/alpaka_inf_1.jpg">
                <div class="information">
                    <a href="/Alpaka">
                        <h1>Альпака в мире природы</h1>
                    </a>
                    <p>Легенда индейцев кечуа, потомков инков, гласит, что когда-то
                        богиня Пачамама спустилась на Землю...</p>
                </div>
                <div class="reiting">
                    <a href=""><img src="images/share.png"></a>
                    <a href=""><img src="images/zakladki.png"></a>
                    <a href=""><img src="images/like3.svg"></a>
                    Просмотрели: 367 людей
                </div>
            </div>
            <div class="box">
                <img src="images/alpaka_inf_2.jpg">
                <div class="information">
                    <h1>Семейство альпак</h1>
                    <p>Альпака, животное с которым наши земляки поближе
                        познакомились не так давно, а только с тех пор как в
                        свободной продаже появилась изделия из альпаки, а немного
                        погодя ткань и пряжа из шерсти этих животных...</p>
                </div>
                <div class="reiting">
                    <a href=""><img src="images/share.png"></a>
                    <a href=""><img src="images/zakladki.png"></a>
                    <a href=""><img src="images/like3.svg"></a>
                    Просмотрели: 459 людей
                </div>
            </div>
            <div class="box">
                <img src="images/alpaka_inf_3.jpg">
                <div class="information">
                    <h1>7 отличий между ламой и альпакой</h1>
                    <p>У ламы и альпаки очень много общего...</p>
                </div>
                <div class="reiting">
                    <a href=""><img src="images/share.png"></a>
                    <a href=""><img src="images/zakladki.png"></a>
                    <a href=""><img src="images/like3.svg"></a>
                    Просмотрели: 605 людей
                </div>
            </div>
            <div class="box">
                <img src="images/alpaka_inf_3.jpg">
                <div class="information">
                    <h1>7 отличий между ламой и альпакой</h1>
                    <p>У ламы и альпаки очень много общего...</p>
                </div>
                <div class="reiting">
                    <a href=""><img src="images/share.png"></a>
                    <a href=""><img src="images/zakladki.png"></a>
                    <a href=""><img src="images/like3.svg"></a>
                    Просмотрели: 605 людей
                </div>
            </div>
            <div class="box">
                <img src="images/alpaka_inf_3.jpg">
                <div class="information">
                    <h1>7 отличий между ламой и альпакой</h1>
                    <p>У ламы и альпаки очень много общего...</p>
                </div>
                <div class="reiting">
                    <a href=""><img src="images/share.png"></a>
                    <a href=""><img src="images/zakladki.png"></a>
                    <a href=""><img src="images/like3.svg"></a>
                    Просмотрели: 605 людей
                </div>
            </div>
        </div>

        <div class="content_right">
            <a href=""><img src="images/reklama1.jpg" width="300">Раскрутка ваших инстраграм аккаунтов</a>
            <a href=""><img src="images/reklama2.jpeg" width="300">Чиним ваши устройства по низким ценам</a>
            <a href=""><img src="images/reklama3.jpg" width="300">Как стал популярен сайт Star</a>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\Maxim\resources\views/avtoriz.blade.php ENDPATH**/ ?>