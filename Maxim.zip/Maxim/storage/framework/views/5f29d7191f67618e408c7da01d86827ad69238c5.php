<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>avtoriz</title>
    <link rel="stylesheet" href="css/style_login.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\Maxim\resources\views/layout/header.blade.php ENDPATH**/ ?>