<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AlpakaController extends Controller
{
    public function index()
    {
        return view('alpakainflora');
    }
}
