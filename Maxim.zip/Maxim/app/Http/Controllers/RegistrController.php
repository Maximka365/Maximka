<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class RegistrController extends Controller
{
    public function registation()
    {
        return view('registration');
    }

    public  function  create(Request $request)
    {
        dump($request->all());

        User::create(['login'=>$request->name,
            'email'=>$request->email,
            'password'=> Hash::make($request->passsword),
            'status'=>0
        ]);

        return redirect('/');
    }
}
